namespace InternalsApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class v2 : DbMigration
    {
        public override void Up()
        {
            CreateIndex("dbo.ClassRoom", "USN");
            AddForeignKey("dbo.ClassRoom", "USN", "dbo.Student", "USN");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ClassRoom", "USN", "dbo.Student");
            DropIndex("dbo.ClassRoom", new[] { "USN" });
        }
    }
}
