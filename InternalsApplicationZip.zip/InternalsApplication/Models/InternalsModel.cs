namespace InternalsApplication.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class InternalsModel : DbContext
    {
        public InternalsModel()
            : base("name=InternalsModel")
        {
        }

        public virtual DbSet<ClassRoom> ClassRooms { get; set; }
        public virtual DbSet<Department> Departments { get; set; }
        public virtual DbSet<Report> Reports { get; set; }
        public virtual DbSet<Script> Scripts { get; set; }
        public virtual DbSet<Student> Students { get; set; }
        public virtual DbSet<Subject> Subjects { get; set; }
        public virtual DbSet<sysdiagram> sysdiagrams { get; set; }
        public virtual DbSet<Teacher> Teachers { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Report>()
                .Property(e => e.Percentage)
                .HasPrecision(5, 3);

        }
    }
}
